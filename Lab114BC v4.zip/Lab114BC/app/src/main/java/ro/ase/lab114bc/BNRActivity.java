package ro.ase.lab114bc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class BNRActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bnr);

        Log.e("lifecycle", "onCreate()");

        TextView tvData = findViewById(R.id.tvData);
        EditText etEUR = findViewById(R.id.editTextEUR);
        EditText etUSD = findViewById(R.id.editTextUSD);
        EditText etGBP = findViewById(R.id.editTextGBP);
        EditText etXAU = findViewById(R.id.editTextXAU);

        Button btnAfisare = findViewById(R.id.btnAfisare);
        btnAfisare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Network network = new Network()
                {
                    @Override
                    protected void onPostExecute(InputStream inputStream) {

                       /* Toast.makeText(getApplicationContext(), Network.rezultat,
                                Toast.LENGTH_LONG).show();*/
                        tvData.setText(cv.getDataCurs());
                        etEUR.setText(cv.getEuro());
                        etUSD.setText(cv.getDolar());
                        etGBP.setText(cv.getLira());
                        etXAU.setText(cv.getAur());
                    }
                };
                try {
                    network.execute(new URL("https://www.bnr.ro/nbrfxrates.xml"));
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }

               /* etEUR.setText("4.9123");
                etUSD.setText("4.5678");
                etGBP.setText("5.2345");
                etXAU.setText("259.9567");

                Toast.makeText(getApplicationContext(), "Ai dat click pe buton!",
                        Toast.LENGTH_LONG).show();*/
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("lifecycle", "onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("lifecycle", "onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("lifecycle", "onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e("lifecycle", "onStop()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.e("lifecycle", "onRestart()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("lifecycle", "onDestroy()");
    }

    @Override
    public void onClick(View view) {

    }
}