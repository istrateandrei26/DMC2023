package ro.ase.lab114bc;

public class CursValutar {

    private String dataCurs;
    private String euro;
    private String dolar;
    private String lira;
    private String aur;

    public CursValutar()
    {

    }

    public CursValutar(String dataCurs, String euro, String dolar, String lira, String aur) {
        this.dataCurs = dataCurs;
        this.euro = euro;
        this.dolar = dolar;
        this.lira = lira;
        this.aur = aur;
    }

    public String getDataCurs() {
        return dataCurs;
    }

    public void setDataCurs(String dataCurs) {
        this.dataCurs = dataCurs;
    }

    public String getEuro() {
        return euro;
    }

    public void setEuro(String euro) {
        this.euro = euro;
    }

    public String getDolar() {
        return dolar;
    }

    public void setDolar(String dolar) {
        this.dolar = dolar;
    }

    public String getLira() {
        return lira;
    }

    public void setLira(String lira) {
        this.lira = lira;
    }

    public String getAur() {
        return aur;
    }

    public void setAur(String aur) {
        this.aur = aur;
    }

    @Override
    public String toString() {
        return "CursValutar{" +
                "dataCurs='" + dataCurs + '\'' +
                ", euro='" + euro + '\'' +
                ", dolar='" + dolar + '\'' +
                ", lira='" + lira + '\'' +
                ", aur='" + aur + '\'' +
                '}';
    }
}
