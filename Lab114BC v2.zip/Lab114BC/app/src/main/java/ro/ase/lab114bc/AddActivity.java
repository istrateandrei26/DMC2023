package ro.ase.lab114bc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_MUZICIAN = "addMuzician";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Intent intent = getIntent();

        String[] genuriMuzicale = {"COUNTRY", "HIP HOP", "ROCK"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                genuriMuzicale);
        Spinner spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adapter);

        EditText etNume = findViewById(R.id.editTextNume);
        EditText etDataNasterii = findViewById(R.id.editTextDate);
        EditText etNrConcerte = findViewById(R.id.editTextNumber);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        Button btnCreare = findViewById(R.id.btnCreare);
        btnCreare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etNume.getText().toString().isEmpty())
                    etNume.setError("Introduceti numele!");
                else
                    if(etDataNasterii.getText().toString().isEmpty())
                        etDataNasterii.setError("Introduceti data!");
                    else
                        if(etNrConcerte.getText().toString().isEmpty())
                            etNrConcerte.setError("Introduceti numar concerte!");
                        else
                        {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy",
                                    Locale.US);
                            try {
                                sdf.parse(etDataNasterii.getText().toString());
                                Date dataNasterii = new Date(etDataNasterii.getText().toString());
                                String nume = etNume.getText().toString();
                                int nrConcerte = Integer.parseInt(etNrConcerte.getText().toString());
                                String genMuzical = spinner.getSelectedItem().toString();
                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                String tipArtist = radioButton.getText().toString();

                                Muzician muzician = new Muzician(nume, dataNasterii, nrConcerte,
                                        genMuzical, tipArtist);
                                /*Toast.makeText(getApplicationContext(),
                                        muzician.toString(), Toast.LENGTH_LONG).show();*/
                                intent.putExtra(ADD_MUZICIAN, muzician);
                                setResult(RESULT_OK, intent);
                                finish();

                            } catch (Exception e) {
                                e.printStackTrace();
                                Toast.makeText(getApplicationContext(), "Eroare introducere date!",
                                        Toast.LENGTH_LONG).show();
                            }
                        }
            }
        });
    }
}