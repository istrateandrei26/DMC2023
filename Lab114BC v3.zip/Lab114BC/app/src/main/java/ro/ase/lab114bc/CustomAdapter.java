package ro.ase.lab114bc;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CustomAdapter extends ArrayAdapter<Muzician> {

    private Context context;
    private int resource;
    private List<Muzician> listaMuzicieni;
    private LayoutInflater layoutInflater;

    public CustomAdapter(@NonNull Context context, int resource, List<Muzician> lista,
                         LayoutInflater layoutInflater) {
        super(context, resource, lista);
        this.context = context;
        this.resource = resource;
        this.listaMuzicieni = lista;
        this.layoutInflater = layoutInflater;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View view = layoutInflater.inflate(resource, parent, false);

        Muzician muzician = listaMuzicieni.get(position);

        if(muzician!=null)
        {
            TextView tv1 = view.findViewById(R.id.tvNume);
            tv1.setText(muzician.getNume());

            TextView tv2 = view.findViewById(R.id.tvDataNasterii);
            tv2.setText(muzician.getDataNasterii().toString());

            TextView tv3 = view.findViewById(R.id.tvNrConcerte);
            tv3.setText(String.valueOf(muzician.getNrConcerte()));

            TextView tv4 = view.findViewById(R.id.tvGenMuzical);
            tv4.setText(muzician.getGenMuzical());

            TextView tv5 = view.findViewById(R.id.tvTipMuzician);
            tv5.setText(muzician.getTipMuzician());
        }
        return view;
    }
}
