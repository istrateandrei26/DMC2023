package ro.ase.lab114bc;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Intent intent;

    public static final int REQUEST_CODE_ADD = 200;

    List<Muzician> listaMuzicieni = new ArrayList<>();

    ListView listView;

    public static final int REQUEST_CODE_EDIT = 300;

    public static final String EDIT_MUZICIAN = "editMuzician";

    int poz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        FloatingActionButton floatingActionButton = findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), AddActivity.class);
                startActivityForResult(intent, REQUEST_CODE_ADD);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                Muzician muzician = listaMuzicieni.get(position);

                ArrayAdapter adapter = (ArrayAdapter) listView.getAdapter();

                AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Confirmare stergere")
                        .setMessage("Doriti sa stergeti?")
                        .setNegativeButton("NU", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getApplicationContext(), "Nu am sters nimic",
                                        Toast.LENGTH_LONG).show();
                                dialogInterface.cancel();
                            }
                        })
                        .setPositiveButton("DA", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                listaMuzicieni.remove(muzician);
                                adapter.notifyDataSetChanged();
                                Toast.makeText(getApplicationContext(), "Am sters "+muzician.toString(),
                                                Toast.LENGTH_LONG).show();
                                dialogInterface.cancel();
                            }
                        }).create();

                dialog.show();

                return true;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                poz = position;
                intent = new Intent(getApplicationContext(), AddActivity.class);
                intent.putExtra(EDIT_MUZICIAN, listaMuzicieni.get(position));
                startActivityForResult(intent, REQUEST_CODE_EDIT);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_CODE_ADD && resultCode == RESULT_OK && data!=null)
        {
            Muzician muzician = (Muzician) data.getSerializableExtra(AddActivity.ADD_MUZICIAN);
            if(muzician!=null)
            {
                /*Toast.makeText(getApplicationContext(),
                        muzician.toString(), Toast.LENGTH_LONG).show();*/
                listaMuzicieni.add(muzician);
                /*ArrayAdapter<Muzician> adapter = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1,
                        listaMuzicieni);*/
                CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                        R.layout.elemlistview, listaMuzicieni, getLayoutInflater())
                {
                    @NonNull
                    @Override
                    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                        View view = super.getView(position, convertView, parent);

                        Muzician muzician1 = listaMuzicieni.get(position);
                        TextView tvNrConcerte = view.findViewById(R.id.tvNrConcerte);
                        if(muzician1.getNrConcerte()<100)
                            tvNrConcerte.setTextColor(Color.RED);
                        else
                            tvNrConcerte.setTextColor(Color.GREEN);

                        return view;
                    }
                };
                listView.setAdapter(adapter);
            }
        }
        else
            if(requestCode==REQUEST_CODE_EDIT && resultCode==RESULT_OK&& data!=null)
            {
                Muzician muzician = (Muzician) data.getSerializableExtra(AddActivity.ADD_MUZICIAN);
                if(muzician!=null)
                {
                    listaMuzicieni.get(poz).setNume(muzician.getNume());
                    listaMuzicieni.get(poz).setDataNasterii(muzician.getDataNasterii());
                    listaMuzicieni.get(poz).setNrConcerte(muzician.getNrConcerte());
                    listaMuzicieni.get(poz).setGenMuzical(muzician.getGenMuzical());
                    listaMuzicieni.get(poz).setTipMuzician(muzician.getTipMuzician());

                    CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                            R.layout.elemlistview, listaMuzicieni, getLayoutInflater())
                    {
                        @NonNull
                        @Override
                        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                            View view = super.getView(position, convertView, parent);

                            Muzician muzician1 = listaMuzicieni.get(position);
                            TextView tvNrConcerte = view.findViewById(R.id.tvNrConcerte);
                            if(muzician1.getNrConcerte()<100)
                                tvNrConcerte.setTextColor(Color.RED);
                            else
                                tvNrConcerte.setTextColor(Color.GREEN);

                            return view;
                        }
                    };
                    listView.setAdapter(adapter);
                }
            }
    }
}