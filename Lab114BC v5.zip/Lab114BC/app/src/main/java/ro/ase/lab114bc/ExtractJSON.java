package ro.ase.lab114bc;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ExtractJSON extends AsyncTask<URL, Void, String> {

    JSONArray muzicieni = null;
    public List<Muzician> listaMuzicieniJSON = new ArrayList<>();

    @Override
    protected String doInBackground(URL... urls) {

        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection)urls[0].openConnection();
            conn.setRequestMethod("GET");

            InputStream ist = conn.getInputStream();

            InputStreamReader isr = new InputStreamReader(ist);
            BufferedReader br = new BufferedReader(isr);
            String linie = null;
            String rezultat = "";
            while ((linie = br.readLine())!=null)
                rezultat+=linie;

            //parsare JSON
            parsareJSON(rezultat);

            return rezultat;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public void parsareJSON(String jsonStr)
    {
        if(jsonStr!=null)
        {
            try {
                JSONObject jsonObject = new JSONObject(jsonStr);

                muzicieni = jsonObject.getJSONArray("muzicieni");
                for(int i=0;i<muzicieni.length();i++)
                {
                    JSONObject object = muzicieni.getJSONObject(i);
                    String nume = object.getString("Nume");
                    Date dataNasterii = new Date(object.getString("DataNasterii"));
                    int nrConcerte = Integer.parseInt(object.getString("NrConcerte"));
                    String genMuzical = object.getString("GenMuzical");
                    String tipMuzician = object.getString("TipMuzician");

                    Muzician muzician = new Muzician(nume, dataNasterii, nrConcerte,
                            genMuzical, tipMuzician);
                    listaMuzicieniJSON.add(muzician);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else
            Log.e("parsareJSON", "JSON este null!");
    }
}
