package ro.ase.lab114bc;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class BNRActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bnr);

        Log.e("lifecycle", "onCreate()");

        TextView tvData = findViewById(R.id.tvData);
        EditText etEUR = findViewById(R.id.editTextEUR);
        EditText etUSD = findViewById(R.id.editTextUSD);
        EditText etGBP = findViewById(R.id.editTextGBP);
        EditText etXAU = findViewById(R.id.editTextXAU);

        Button btnAfisare = findViewById(R.id.btnAfisare);
        btnAfisare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Network network = new Network()
                {
                    @Override
                    protected void onPostExecute(InputStream inputStream) {

                       /* Toast.makeText(getApplicationContext(), Network.rezultat,
                                Toast.LENGTH_LONG).show();*/
                        tvData.setText(cv.getDataCurs());
                        etEUR.setText(cv.getEuro());
                        etUSD.setText(cv.getDolar());
                        etGBP.setText(cv.getLira());
                        etXAU.setText(cv.getAur());
                    }
                };
                try {
                    network.execute(new URL("https://www.bnr.ro/nbrfxrates.xml"));
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }

               /* etEUR.setText("4.9123");
                etUSD.setText("4.5678");
                etGBP.setText("5.2345");
                etXAU.setText("259.9567");

                Toast.makeText(getApplicationContext(), "Ai dat click pe buton!",
                        Toast.LENGTH_LONG).show();*/
            }
        });

        Button btnSalvare = findViewById(R.id.btnSalvare);
        btnSalvare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CursValutar cursValutar = new CursValutar(tvData.getText().toString(),
                        etEUR.getText().toString(),
                        etUSD.getText().toString(),
                        etGBP.getText().toString(),
                        etXAU.getText().toString());

                try {
                    scrieInFisier("fisier.dat", cursValutar);
                    cursValutar = null;
                    cursValutar = citireDinFisier("fisier.dat");
                    Toast.makeText(getApplicationContext(), cursValutar.toString(),
                            Toast.LENGTH_LONG).show();

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("lifecycle", "onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("lifecycle", "onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("lifecycle", "onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e("lifecycle", "onStop()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.e("lifecycle", "onRestart()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("lifecycle", "onDestroy()");
    }

    @Override
    public void onClick(View view) {

    }

    private void scrieInFisier(String numeFisier, CursValutar cv) throws IOException {

        FileOutputStream fisier = openFileOutput(numeFisier, Activity.MODE_PRIVATE);
        DataOutputStream dos = new DataOutputStream(fisier);
        dos.writeUTF(cv.getDataCurs());
        dos.writeUTF(cv.getEuro());
        dos.writeUTF(cv.getDolar());
        dos.writeUTF(cv.getLira());
        dos.writeUTF(cv.getAur());
        dos.flush();
        fisier.close();
    }

    private CursValutar citireDinFisier(String numeFisier) throws IOException
    {
        FileInputStream fisier = openFileInput(numeFisier);
        DataInputStream dis = new DataInputStream(fisier);
        String data = dis.readUTF();
        String euro = dis.readUTF();
        String dolar = dis.readUTF();
        String lira = dis.readUTF();
        String aur = dis.readUTF();
        CursValutar cv = new CursValutar(data, euro, dolar, lira, aur);
        fisier.close();
        return cv;
    }
}